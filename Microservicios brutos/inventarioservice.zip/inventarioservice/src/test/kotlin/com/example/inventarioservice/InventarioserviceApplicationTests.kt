package com.example.inventarioservice

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class InventarioserviceApplicationTests {

	@Test
	fun contextLoads() {
	}

}
