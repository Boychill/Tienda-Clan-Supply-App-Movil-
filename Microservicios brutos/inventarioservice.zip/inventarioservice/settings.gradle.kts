rootProject.name = "inventarioservice"
