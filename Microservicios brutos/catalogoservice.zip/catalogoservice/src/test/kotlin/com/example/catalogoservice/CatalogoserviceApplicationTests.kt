package com.example.catalogoservice

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class CatalogoserviceApplicationTests {

	@Test
	fun contextLoads() {
	}

}
