package com.example.supplierservice

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SupplierserviceApplicationTests {

	@Test
	fun contextLoads() {
	}

}
