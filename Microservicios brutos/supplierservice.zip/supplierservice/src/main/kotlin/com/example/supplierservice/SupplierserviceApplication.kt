package com.example.supplierservice

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class SupplierserviceApplication

fun main(args: Array<String>) {
	runApplication<SupplierserviceApplication>(*args)
}
