rootProject.name = "supplierservice"
