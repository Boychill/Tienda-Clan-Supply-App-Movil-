rootProject.name = "authservice"
