package com.example.ordenservice

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class OrdenserviceApplication

fun main(args: Array<String>) {
	runApplication<OrdenserviceApplication>(*args)
}
